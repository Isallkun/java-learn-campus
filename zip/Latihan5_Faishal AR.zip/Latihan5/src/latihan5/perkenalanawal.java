/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan5;

/**
 *
 * @author isalr
 */
public class perkenalanawal {
    public static void main(String[] args) {
    String nim = "202169040009",
           nama = "Faishal Ananta Ridha",
           jurusan = "Teknik Informatika",
           smstr = "1",
           kelas    = "A";
    System.out.println("Hallo...ini adalah perkenalan pertama saya");
    System.out.println("=====================================");
    System.out.println("Nama             : " + nama );
    System.out.println("NIM              : " + nim );
    System.out.println("Jurusan          : " + jurusan );
    System.out.println("Semester & Kelas : " + smstr + kelas);
    System.out.println("=====================================");
    
    }    
}
