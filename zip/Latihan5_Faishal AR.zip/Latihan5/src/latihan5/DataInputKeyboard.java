/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan5;

/**
 *
 * @author isalr
 */
public class DataInputKeyboard {
        public static void main(String[] args){
        System.out.println("Contoh Baca Data Input Keyboard");
        
            System.out.print("Masukkan Nama : ");;
            String nama = BacaKeyboard.bacaString();
        
            System.out.println("Hallo," + nama);
               
    } 
}
