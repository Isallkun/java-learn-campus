/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan4;

/**
 *
 * @author isalr
 */
public class OperatorAritmatika {
public static void main(String[] args) {

//variabel
int i = 20, j = 30 ;
double x = 27.475, y = 7.22;

System.out.println("nilai pada variabel...");
System.out.println(" i = " + i);
System.out.println(" j = " + j);
System.out.println(" x = " + x);
System.out.println(" y = " + y);

//penjumlahan angka
System.out.println("penjumlahan...");
System.out.println(" i + j = " + (i + j));
System.out.println(" x + y = " + (x + y));

//pengurangan angka
System.out.println("pengurangan...");
System.out.println(" i - j = " + (i - j));
System.out.println(" x - y = " + (x - y));

//perkalian angka
System.out.println("perkalian...");
System.out.println(" i * j = " + (i * j));
System.out.println(" x * y = " + (x * y));

//pembagian angka
System.out.println("pembagian...");
System.out.println(" i / j = " + (i / j));
System.out.println(" x / y = " + (x / y));

//menghitung hasil modulus dari pembagian
System.out.println("Sisa pembagian (modulus)...");
System.out.println(" i % j = " + (i % j));
System.out.println(" x % y = " + (x % y));

//tipe penggabungan
System.out.println("gabungan...");
System.out.println(" j + y = " + (j + y));
System.out.println(" i * x = " + (i * x));
}
}

