/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan6;

/**
 *
 * @author isalr
 */
public class PernyataanSwitch {
    public static void main( String[] args ){
    int grade = 9;
    
    switch(grade){
    case 1:
        System.out.println( "nasi rawon!" );
        break;
    case 2:
        System.out.println("nasi pecel!" );
        break;
    case 3:
        System.out.println("nasi soto" );
        break;
    default:
        System.out.println("nasi goreng");
    } 
    }
}
