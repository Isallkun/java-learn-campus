/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan6;
/**
 *
 * @author isalr
 */
public class PernyataanIFBertingkat {
    public static void main( String[] args ){
       int grade = 68;
       if( grade > 90 ){
           System.out.println("Very Good!");
       }
       else
        if( grade > 60 ){
	System.out.println("Good!");
          }
       else{
	System.out.println("Sorry You Failed");
         }
    }
}
