/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package latihan9;

/**
 *
 * @author isalr
 */
public class arraykota {
    public static void main(String[] args){
		String[] kota;			//deklarasi variabel array
		kota = new String[3];		// membuat objek array
		// mengisi elemen array
		kota[0]= "Pasuruan";
		kota[1] = "Malang";
		kota[2] = "Surabaya";
		// menampilkan elemen array
		System.out.println(kota[0]);
		System.out.println(kota[1]);
		System.out.println(kota[2]);
	}

}
