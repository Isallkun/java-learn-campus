/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan9;

/**
 *
 * @author isalr
 */
public class NegaraKota {
    public static void main(String[] args){
        String[] NamaNegara = {"Amerika", "Inggris", "Jepang", "Perancis", "Indonesia", "Iran", "Irak"};
        String[] Ibukota = {"Teheran", "Bekasi", "Jakarta", "Bantar Gebang", "Tokyo" };
        
        System.out.println("Ibukota " + NamaNegara[4] + " adalah " + Ibukota[2] );
        System.out.println("Ibukota " + NamaNegara[2] + " adalah " + Ibukota[4] );
        System.out.println("Ibukota " + NamaNegara[5] + " adalah " + Ibukota[0] );
    }
}
